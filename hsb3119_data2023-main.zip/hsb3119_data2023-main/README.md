# hsb3119_data2023
This repository contains data to be used for the HSB3119 Introduction to Data Science course in HSB, for MAS1 2023 Semester 1.
